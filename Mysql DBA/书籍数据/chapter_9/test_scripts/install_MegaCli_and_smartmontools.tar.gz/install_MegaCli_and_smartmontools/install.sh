#!/bin/bash
# test on rhel5.4 64bit
if [ -x /opt/MegaRAID/MegaCli/MegaCli64 ];then
  echo " have installed /opt/MegaRAID/MegaCli/MegaCli64 "
  exit 0
fi
rpm -Uvh Lib_Utils-1.00-08.noarch.rpm
rpm -Uvh MegaCli-8.01.06-1.i386.rpm
tar zxf  smartmontools-5.40.tar.gz
cd smartmontools-5.40
./configure --with-selinux=no && make -j 7  > /dev/null
make install
if [ "$?" != "0" ]; then
   echo "install smartmontools-5.40 error"
   exit 99
fi
cd ..
rm -r smartmontools-5.40
